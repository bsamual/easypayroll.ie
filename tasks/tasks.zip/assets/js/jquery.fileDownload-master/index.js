module.exports = require('./src/Scripts/jquery.fileDownload');
