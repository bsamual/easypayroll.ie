RECOMMENDATIONS
===============

### Artsiom Chorny

Артём Чёрный \<1203994@gmail.com\> *Dec 14, 2018*

> Hi Nick,
>
> I faced a need to apply freezing for header and column of table at the same time during development. So, I've found your library (jquery-freeze-table) after few days of searching. It's completely that I wanted to get. 
> 
> Therefore I'd like to Thank you and show respect. Because I've finally got happiness. It's due to your merit and great work. You rock :)
>
> **Yours respectfully,**  
> **Artsiom Chorny**
