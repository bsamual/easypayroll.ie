<div style="float:left;width:100%;margin:0;padding:0;min-height:100%;line-height:150%;color:#565a5c;background-color:#f7f7f7;">
    <div style="background:#fff; width:65%; overflow:hidden;text-align:left;padding:15px;margin:30px auto 30px;display:block;">
        <div style="width:94%; height:auto; padding:20px; text-align:center; float:left;">
            <a href="#" style="width:100%; float:left;"><img src="<?php echo $logo; ?>" style="margin:0px auto;" /></a>
        </div>
        <div style="width:100%; float:left; height:auto; padding:20px;">
            <div style="width:100%; margin-bottom:15px;">
                <?php echo $message; ?><br/><br/>
                <b>This Email has been sent to : </b> <?php echo $sentmails; ?><br/><br/>
            </div>
        </div>
    </div>
</div>